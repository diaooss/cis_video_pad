//
//  RootViewController.h
//  Video_game_Pad
//
//  Created by huangfangwang on 13-9-18.
//  Copyright (c) 2013年 com.huanfang. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface RootViewController : UITabBarController<UITabBarControllerDelegate,UISearchBarDelegate,UIPopoverControllerDelegate>

@end
