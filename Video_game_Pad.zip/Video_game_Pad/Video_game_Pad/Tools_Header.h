//
//  Tools_Header.h
//  Video_game_Pad
//
//  Created by huangfangwang on 13-9-18.
//  Copyright (c) 2013年 com.huanfang. All rights reserved.
//

#ifndef Video_game_Pad_Tools_Header_h
#define Video_game_Pad_Tools_Header_h
//设定view位置
#import"UIViewAdditions.h"
#endif
